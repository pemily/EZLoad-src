#!/bin/sh

java -jar EZLoad-1.0.jar
