#!/bin/sh

java -jar EZLoad-1.1.jar
